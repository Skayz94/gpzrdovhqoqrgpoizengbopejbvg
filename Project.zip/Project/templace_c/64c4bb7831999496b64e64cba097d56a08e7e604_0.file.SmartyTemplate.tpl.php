<?php
/* Smarty version 3.1.34-dev-7, created on 2020-11-05 15:12:02
  from 'C:\wamp64\www\Project\templates\SmartyTemplate.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5fa416425029b9_30551980',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '64c4bb7831999496b64e64cba097d56a08e7e604' => 
    array (
      0 => 'C:\\wamp64\\www\\Project\\templates\\SmartyTemplate.tpl',
      1 => 1604589080,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5fa416425029b9_30551980 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h1>Bonjour <?php echo $_smarty_tpl->tpl_vars['prenom']->value;?>
 </h1><?php }
}
