<?php

class usersManager {

    // DECLARATIONS ET INSTANCIATIONS
    private $bdd; // Instance de PDO
    private $result;
    private $message;
    private $users; // Instance de utilisateurs
    private $getLastInsertId;

    public function __construct(PDO $bdd) {
        $this->setBdd($bdd);
    }

    function getBdd() {
        return $this->bdd;
    }

    function getResult() {
        return $this->result;
    }

    function getMessage() {
        return $this->message;
    }

    function getUsers() {
        return $this->users;
    }

    function getByEmail() {
        return $this->byemail;
    }
    
    function getGetLastInsertId() {
        return $this->getLastInsertId;
    }

    function setBdd($bdd): void {
        $this->bdd = $bdd;
    }

    function setResult($result): void {
        $this->result = $result;
    }

    function setMessage($message): void {
        $this->message = $message;
    }

    function setUsers($users): void {
        $this->users = $users;
    }
    
    function setByEmail($byemail): void {
        $this->byemail = $byemail;
    }

    function setGetLastInsertId($getLastInsertId): void {
        $this->getLastInsertId = $getLastInsertId;
    }

    public function get($id) {
        // Prépare une requête de type SELECT avec une clause WHERE selon l'id
        $sql = 'SELECT * FROM users WHERE id = :id';
        $req = $this->bdd->prepare($sql);

        // Exécution de la requête avec attribution des valeurs aux marqueurs nominatifs
        $req->bindValue(':id', $id, PDO::PARAM_INT);
        $req->execute();

        // On stocke les données obtenues dans un tableau.
        $donnees = $req->fetch(PDO::FETCH_ASSOC);

        $users = new users();
        $users->hydrate($donnees);

        //print_r2($users);
        return $users;
    }

    public function getList() {
        $listUsers = [];

        // Prépare une requête de type SELECT avec une clause WHERE selon l'id
        $sql = 'SELECT id,'
                . 'nom,'
                . 'prenom,'
                . 'email,'
                . 'mdp'
                . 'sid'
                . 'FROM utilisateurs';
        $req = $this->bdd->prepare($sql);

        // Exécution de la requête avec attribution des valeurs aux marqueurs nominatifs
        $req->execute();

        // On stocke les données obtenues dans un tableau.
        while ($donnees = $req->fetch(PDO::FETCH_ASSOC)) {
            $users = new users();
            $users->hydrate($donnees);
            $listUsers[] = $users;
        }
        //print_r2($listUsers);
        return $listUsers;
    }

    public function add(users $users) {
        $sql = "INSERT INTO users "
                . "(nom, prenom, email, mdp, sid) "
                . "VALUES (:nom, :prenom, :email, :mdp, :sid)";
        $req = $this->bdd->prepare($sql);
        // Sécurisation des variables
        $req->bindValue(':nom', $users->getPrenom(), PDO::PARAM_STR);
        $req->bindValue(':prenom', $users->getNom(), PDO::PARAM_STR);
        $req->bindValue(':email', $users->getEmail(), PDO::PARAM_STR);
        $req->bindValue(':mdp', $users->getMdp(), PDO::PARAM_STR);
        $req->bindValue(':sid', $users->getSid(), PDO::PARAM_STR);
        //Exécuter la requête
        $req->execute();
        if ($req->errorCode() == 00000) {
            $this->result = true;
            $this->getLastInsertId = $this->bdd->lastInsertId();
        } else {
            $this->result = false;
        }
        return $this;
    }

    public function updateByEmail(users $users) {
        $sql = "UPDATE users SET sid = :sid WHERE email = :email";
        $req = $this->bdd->prepare($sql);
        //Sécurisation des variables
        $req->bindValue(':email', $users->getEmail(), PDO::PARAM_STR);
        $req->bindValue(':sid', $users->getSid(), PDO::PARAM_STR);
        if ($req->errorCode() == 00000) {
            $this->result = true;
        } else {
            $this->result = false;
        }
        return $this;
    }
}
